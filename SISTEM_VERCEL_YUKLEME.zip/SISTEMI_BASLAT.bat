@echo off
title Operasyonel Analiz Suite (AI Edition)
color 0B
echo -----------------------------------------------------------------
echo PEGASUS OPERASYONEL ANALIZ SUITE (V2) GUC VERILIYOR...
echo -----------------------------------------------------------------
echo Lutfen acilan siyah ekrani kapatmayin, bu panel arka planda matematiksel
echo ve Yapay Zeka (AI) islemcisini ayakta tutan ana lokal sunucudur.
echo.
echo Sistem hazirlanip tarayicinizda (Chrome/Edge vb.) otomatik olarak acilacaktir...
echo.

start "Browser" cmd /c "timeout /t 5 >nul && start http://localhost:3000"
call npm run dev

pause
